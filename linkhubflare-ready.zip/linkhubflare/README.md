# LinkHub Flare — международная биржа размещения ссылок
Домен: linkhubflare.com (проверьте написание).

Модель: продавец ставит цену (ask), покупатель — бюджет (bid). Платформа подбирает пару
по теме, качеству и рейтингу. Разница bid − ask = доход платформы. Пример: ask 40, bid 120 → 80.

- docs/ARCHITECTURE.md — архитектура, проверки, статусы заказа, SEO, дорожная карта
- db/schema.sql — схема PostgreSQL
- src/matching.js, src/matching.test.js — движок подбора (node src/matching.test.js)
- web/ — SEO-основа: главная, robots.txt, sitemap.xml, hreflang, JSON-LD
- prototype/ — прежний UI-прототип

Правило №1: каждая оплаченная ссылка размещается с rel="sponsored" (политика Google).
Оплата подключается последней: модуль payments и эскроу-статусы заложены в схеме.
