// Перенос данных из data/db.json в PostgreSQL:  DATABASE_URL=... node scripts/migrate-json-to-pg.js [путь/к/db.json]
const { open, openPg } = require('../lib/store');
(async () => {
  const src = open(process.argv[2] || 'data/db.json'), dst = await openPg(process.env.DATABASE_URL, { ssl: process.env.PGSSL });
  if (dst.d.users.length) { console.error('PostgreSQL уже содержит данные — перенос отменён'); process.exit(1); }
  for (const k of ['users', 'listings', 'requests', 'orders', 'ledger', 'withdrawals']) dst.d[k].push(...(src.d[k] || []));
  dst.d.seq = src.d.seq; dst.save(); await dst.close();
  console.log('Перенесено: ' + ['users', 'listings', 'requests', 'orders', 'ledger', 'withdrawals'].map(k => k + '=' + (src.d[k] || []).length).join(', '));
})();
