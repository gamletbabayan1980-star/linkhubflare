// node scripts/hash-admin-code.js "ВАШ_КОД"  ->  вставьте результат в ADMIN_CODE_HASH
console.log(require('../lib/auth').hashPassword(process.argv[2] || (() => { throw new Error('usage: node scripts/hash-admin-code.js CODE'); })()));
