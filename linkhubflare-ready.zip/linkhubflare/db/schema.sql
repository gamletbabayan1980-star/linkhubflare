CREATE TYPE user_role AS ENUM ('buyer','seller','both','admin');
CREATE TYPE listing_status AS ENUM ('pending','verifying','review','approved','rejected','hidden');
CREATE TYPE order_status AS ENUM ('open','matched','paid','in_progress','published','verified','payout','dispute','refunded','cancelled');

CREATE TABLE users(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), email TEXT UNIQUE NOT NULL,
  password_hash TEXT NOT NULL, role user_role NOT NULL DEFAULT 'buyer', locale TEXT DEFAULT 'en',
  country CHAR(2), mfa_enabled BOOL DEFAULT false, kyc_status TEXT DEFAULT 'none', created_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE listings(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), seller_id UUID REFERENCES users(id),
  domain TEXT UNIQUE NOT NULL, category TEXT NOT NULL, language CHAR(2), country CHAR(2),
  ask_price_cents INT NOT NULL CHECK(ask_price_cents>0), currency CHAR(3) DEFAULT 'USD',
  status listing_status DEFAULT 'pending', ownership_verified BOOL DEFAULT false,
  trust_score SMALLINT, created_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE trust_checks(id BIGSERIAL PRIMARY KEY, listing_id UUID REFERENCES listings(id),
  kind TEXT NOT NULL, score SMALLINT, details JSONB, checked_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE requests(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), buyer_id UUID REFERENCES users(id),
  target_url TEXT NOT NULL, category TEXT NOT NULL, language CHAR(2), country CHAR(2),
  bid_price_cents INT NOT NULL, min_trust SMALLINT DEFAULT 70, anchor TEXT, created_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE orders(id UUID PRIMARY KEY DEFAULT gen_random_uuid(), request_id UUID REFERENCES requests(id),
  listing_id UUID REFERENCES listings(id), buyer_id UUID, seller_id UUID,
  bid_cents INT NOT NULL, ask_cents INT NOT NULL, spread_cents INT GENERATED ALWAYS AS (bid_cents-ask_cents) STORED,
  status order_status DEFAULT 'open', published_url TEXT, rel_attr TEXT DEFAULT 'sponsored',
  created_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE link_checks(id BIGSERIAL PRIMARY KEY, order_id UUID REFERENCES orders(id),
  http_status INT, link_present BOOL, rel_ok BOOL, checked_at TIMESTAMPTZ DEFAULT now());

CREATE TABLE seller_stats(seller_id UUID PRIMARY KEY REFERENCES users(id), completed INT DEFAULT 0,
  disputes INT DEFAULT 0, avg_publish_hours NUMERIC, link_survival_pct NUMERIC, rating NUMERIC);

CREATE TABLE messages(id BIGSERIAL PRIMARY KEY, order_id UUID, sender_id UUID, body TEXT, created_at TIMESTAMPTZ DEFAULT now());
CREATE TABLE ledger(id BIGSERIAL PRIMARY KEY, order_id UUID, kind TEXT, amount_cents INT, created_at TIMESTAMPTZ DEFAULT now()); -- модуль payments, подключается последним
CREATE INDEX ON listings(status, category, language);
