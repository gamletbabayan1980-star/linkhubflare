# Правила для продавцов / Seller rules (версия seller-rules-1)

> Черновик для проверки юристом. Согласие фиксируется при регистрации (дата и версия). Текст в кабинете берётся из `backend/public/app/index.html` (ключи rl_1..rl_9); на языках, кроме русского и английского, правила пока показываются на английском.

## Русский

1. Ссылка должна быть размещена на указанной странице вашего сайта с атрибутом rel="sponsored" (допускается добавить nofollow). Без этого оплата не производится.
2. Разместить ссылку нужно в течение 5 дней после оплаты покупателем. Иначе заказ отменяется, деньги возвращаются покупателю, а вашему рейтингу назначается штраф.
3. После размещения платформа сама проверяет ссылку автоматически (при необходимости повторно в течение 72 часов). Если ссылка не найдена, заказ отменяется и деньги возвращаются покупателю.
4. Выплата происходит не сразу: после первой успешной проверки средства удерживаются 7 дней. В конце удержания ссылка проверяется ещё раз. Если ссылки нет, выплаты не будет и деньги вернутся покупателю.
5. После выплаты ссылка должна оставаться на месте не менее 180 дней без изменений (адрес страницы, текст ссылки, атрибут rel). Платформа проверяет её через 30, 90 и 180 дней.
6. Если ссылка удалена или изменена после выплаты, покупателю возвращаются деньги за счёт платформы, а сумма вашей выплаты записывается как долг и удерживается из ваших следующих выплат. Рейтинг снижается.
7. Три нарушения (не опубликовано вовремя, ссылка удалена) приводят к скрытию ваших сайтов. Восстановление возможно только по решению администрации.
8. Запрещены сети сайтов для продажи ссылок (PBN), спам, накрутка трафика, скрытый текст, взломанные и чужие сайты. Подтверждение владения через DNS обязательно.
9. Вы получаете ровно ту цену, которую сами указали. Цену покупателя вы не видите, и это нормально. Сделки и платежи в обход платформы запрещены. Ваше согласие с правилами фиксируется (дата и версия правил).

## English

1. The link must be placed on the specified page of your website with rel="sponsored" (nofollow may be added). Without it, no payment is made.
2. You must place the link within 5 days after the buyer pays. Otherwise the order is cancelled, the buyer is refunded and your rating receives a penalty.
3. After you publish, the platform checks the link automatically (repeatedly within 72 hours if needed). If the link is not found, the order is cancelled and the buyer is refunded.
4. Payout is not immediate: after the first successful check the funds are held for 7 days. At the end of the hold the link is checked again. If it is missing, no payout is made and the buyer is refunded.
5. After payout the link must stay in place unchanged (page address, anchor text, rel attribute) for at least 180 days. The platform checks it after 30, 90 and 180 days.
6. If the link is removed or changed after payout, the buyer is refunded by the platform, and the amount of your payout is recorded as a debt deducted from your future payouts. Your rating drops.
7. Three violations (not published in time, link removed) lead to your websites being hidden. Restoration is possible only by a decision of the administration.
8. Link-selling site networks (PBN), spam, fake traffic, hidden text, hacked or third-party websites are prohibited. Ownership verification via DNS is mandatory.
9. You receive exactly the price you set. You do not see the buyer’s price, and that is normal. Deals and payments outside the platform are prohibited. Your acceptance of these rules is recorded (date and rules version).

## Параметры (backend)
| Параметр | Значение по умолчанию | Где задаётся |
|---|---|---|
| Срок публикации после оплаты | 5 дней | `publishDeadlineDays` в createApp |
| Окно повторных проверок после публикации | 72 часа | `checkWindowHours` |
| Удержание выплаты | 7 дней | `HOLD_DAYS` (переменная окружения) |
| Контроль после выплаты | 30 / 90 / 180 дней | `MONITOR` в server.js |
| Автопроверка | каждые 10 минут | таймер в server.js |
| Скрытие сайтов продавца | 3 нарушения | `penalize()` |
