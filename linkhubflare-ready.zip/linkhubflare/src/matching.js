// Слепой подбор. Продавец получает ровно свою цену (ask), покупатель платит ровно свой бюджет (bid).
// Разница (spread) — доход платформы. Стороны не видят цены друг друга.
// 1) Качество — жёсткий фильтр. 2) Среди прошедших берём самую низкую цену продавца.
// 3) Заявки обрабатываются от самой высокой ставки к низкой.
function eligible(l, r) {
  return l.status === 'approved' && l.ownershipVerified && l.ask <= r.bid
    && l.trust >= (r.minTrust ?? 70)
    && (!r.language || l.language === r.language)
    && (!r.country || !l.country || l.country === r.country)
    && (l.category === r.category || (l.relatedCategories || []).includes(r.category));
}

function matchAll(listings, requests) {
  const taken = new Set(), deals = [];
  const queue = requests.flatMap(r => Array.from({ length: r.qty || 1 }, () => r)); // qty сайтов = qty ссылок
  for (const r of queue.sort((a, b) => b.bid - a.bid)) {
    const best = listings.filter(l => !taken.has(l.id) && eligible(l, r))
      .sort((a, b) => (a.category === r.category ? 0 : 1) - (b.category === r.category ? 0 : 1) || a.ask - b.ask || b.trust - a.trust)[0];
    if (!best) continue;
    taken.add(best.id);
    deals.push({ requestId: r.id, listingId: best.id, buyerPays: r.bid, sellerGets: best.ask, spread: r.bid - best.ask });
  }
  return deals;
}

// То, что видит каждая сторона: только свои цифры.
const buyerView = d => ({ requestId: d.requestId, pays: d.buyerPays });
const sellerView = d => ({ listingId: d.listingId, receives: d.sellerGets });
module.exports = { matchAll, buyerView, sellerView };
