# LINKHUB FLARE — International Marketplace Prototype

This ZIP contains an expanded, responsive front-end prototype for the LINKHUB FLARE backlink placement marketplace.

## Included in this version
- 13 language choices: English, Russian, German, French, Spanish, Armenian, Hindi, Chinese, Brazilian Portuguese, Korean, Malay, Arabic and Turkish.
- Separate buyer, seller/publisher and combined buyer+seller registration roles.
- Separate administrator demo entry and admin dashboard preview.
- Buyer marketplace, publisher website submission, order list and Trust & Anti-Spam screens.
- Three demo chat conversations: buyer, seller/publisher and administrator.
- Responsive desktop and mobile layout.
- Demo order creation, role-based interface behavior, sample website listings and settings.

## Run
Unzip the archive and open `index.html` in a modern browser. No build tools are required.

## Important — prototype limitations
This is a front-end prototype. It does NOT yet include production authentication, secure password handling, backend/database, real-time messaging, payment processing, seller payouts, domain ownership verification, real SEO metrics, crawler-based spam checks, moderation audit logs or production localization review. Demo chats and data are local to the browser session. Sample domains use `.example` and all metrics are illustrative.

The admin demo entry is for preview only. A real admin system must use a separate protected server-side role, MFA, audit logs and strict access control. Never deploy a public admin password or rely on front-end-only role checks.

## Recommended production architecture
- Frontend: Next.js / TypeScript with server-rendered SEO pages and accessible responsive UI.
- Backend: API service with PostgreSQL, Redis queues and object storage.
- Identity: secure email verification, password hashing, MFA for admins, role-based access control (RBAC).
- Messaging: persisted conversations, participant permissions, abuse reporting and moderation.
- Payments: marketplace payment provider, delayed payout/escrow-like workflow where legally supported, refunds and seller KYC/AML where required.
- Trust: DNS TXT / HTML ownership verification, crawler, source-linked metrics, anti-spam rules, review queue and periodic link checks.
- International: locale-aware routes, translated metadata, hreflang, canonical URLs, localized currencies/time zones and right-to-left Arabic layout.
- Compliance: privacy policy, terms, cookies, data retention, consumer/payment rules and clear disclosure of sponsored links.

## Suggested next milestone
Build the real backend foundation first: database schema, secure registration/login, buyer/seller/both roles, admin RBAC, conversations and order state machine. Then connect the crawler and payment provider.
